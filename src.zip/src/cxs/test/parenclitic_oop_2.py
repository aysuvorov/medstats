# coding: utf-8

import numpy as np
import pandas as pd
import networkx as nx
import warnings
import statsmodels.api as sma 

from itertools import combinations
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler
warnings.filterwarnings("ignore")


class Zanin(object):
    """
    ## Zanin algorithm for parenclitic graphs

    Attributes
    ----------
    :X_fitter: pd.core.frame.DataFrame
        Data frame with features from healthy subjects
        'id' must be set as an index
    

    :nodes_lst: list with feature names
        Theese features will be used to construct
        graphs

    Examples
    --------
    >>> dataloader = DataLoader(X_healthy, Y_healthy, nodes)
    >>> clf = DataFitter(dataloader, df-with-new-data)
    >>> clf.create_chars()

    """

    def __init__(
            self, 
            X_fitter: pd.core.frame.DataFrame,
            nodes_lst: list
        )-> None:
        """        
        """
        self.X_fitter = X_fitter
        self.nodes_lst = nodes_lst


class Features(object):
    """[summary]

    Args:
        object ([type]): [description]
    """    
    def __init__(
            self, 
            nodes: Zanin
            ) -> None:
        
        self.nodes = nodes.nodes_lst


    def fit(self):
        feature_lst = []
        tuples_lst = []

        for i in list(combinations(self.nodes, r = 2)):
            tuples_lst = tuples_lst + [i]
            feature_lst = feature_lst + [i[0] + '-' + i[1]]

        self.feature_lst = feature_lst
        self.tuples_lst = tuples_lst


class Model(object):
   
    def __init__(
            self, 
            training_data: Zanin,
            features: Features
            ) -> None:
        self.training_data = training_data.X_fitter
        self.tuples_lst = features.tuples_lst
    

    def fit(self) -> None:
        model_lst = []

        for i in self.tuples_lst: 

            X = sma.add_constant(self.training_data[i[1]])
            y = self.training_data[i[0]]
            model_ols = sma.OLS(y, X).fit()
            model_lst = model_lst + [model_ols]
        self.model_lst = model_lst


class NewData(object):
    """[summary]

    Args:
        object ([type]): [description]
    """    
    def __init__(
            self, 
            newdata: pd.core.frame.DataFrame,
            zanin_fitted: Zanin,
            features: Features, 
            models: Model
        ) -> None:
        self.newdata = newdata
        self.nodes = features.nodes
        self.tuples_lst = features.tuples_lst
        self.feature_lst = features.feature_lst
        self.model_lst = models.model_lst
        self.X_fitter = zanin_fitted.X_fitter


    def newdata_fit(
            self, 
            newdata: pd.core.frame.DataFrame,
        ) -> pd.core.frame.DataFrame:
        """[summary]

        Args:
            newdata (pd.core.frame.DataFrame): [description]

        Returns:
            pd.core.frame.DataFrame: [description]
        """        
        for i, model in zip(self.tuples_lst, self.model_lst): 
            newdata[i[0] + '-' + i[1]] = model.predict(
                                sma.add_constant(newdata[i[1]])) - newdata[i[0]]
        return(newdata.drop(self.nodes, axis=1))


    def fit(self) -> None:
        """[summary]
        """        
        self.newdata = self.newdata_fit(self.newdata)
        cols = [x for x in self.feature_lst]
        healthy_data = self.newdata_fit(self.X_fitter)
        sc = StandardScaler()
        sc = sc.fit(healthy_data[cols])
        self.newdata[cols] = abs(sc.transform(self.newdata[cols]))


class GraphBasket(object):
    """[summary]

    Args:
        object ([type]): [description]
    """    
    def __init__(
            self, 
            data: NewData,
            features: Features
        ) -> None:
        
        self.data = data.newdata
        self.index = self.data.index
        self.nodes = features.nodes
        self.tuples_lst = features.tuples_lst
        self.feature_lst = features.feature_lst

    def fit(self)-> None:
        """[summary]
        """        
        self.graphs = dict()

        for elems in self.index:
            G = nx.Graph()
            G.add_nodes_from(self.nodes)
            for e, w in zip(self.tuples_lst, self.feature_lst):
                G.add_edge(e[0], e[1], weight = \
                    float(self.data.loc[elems, w]))

            self.graphs[elems] = G

    def params(self, gg)-> np.array:
        """[summary]

        Args:
            gg ([type]): [description]

        Returns:
            np.array: [description]
        """        
        weight = 'weight'
        norm = False

        clsns = nx.closeness_centrality(gg, distance=weight, wf_improved=norm).values()
        btwnns = nx.betweenness_centrality(gg, weight=weight, normalized=norm).values()
        edge_btwnns = nx.edge_betweenness_centrality(gg, weight=weight, normalized=norm).values()
        pgrnk = nx.pagerank(gg, weight=weight).values()
        eign = nx.eigenvector_centrality(gg, weight=weight).values()
        auth = nx.hits(gg)[1].values()
        strength = dict(gg.degree(weight=weight)).values()

        combo = [btwnns, clsns, edge_btwnns, pgrnk, eign, auth, strength]
        combo = [np.fromiter(x, dtype=float) for x in combo]
        subarray = np.ravel([[np.mean(x), np.median(x), np.std(x), np.max(x), np.max(x)] for x in combo])       
        return(subarray)
    
    
    def compute(self) -> None:

        names = ['btwnns', 'clsns', 'edge_btwnns', 'pgrnk', 'eign', 'auth', 'strength']
        func_names = ['_mean', '_median', '_std', '_min', '_max']
        columns = [x+y for x in names for y in func_names]

        mtx = []

        for graph in range(len(self.graphs)):
            gg = [*self.graphs.values()][graph]
            row = self.params(gg)
            mtx = mtx + [row]

        self.chars = pd.DataFrame(
                    data=np.array(mtx), 
                    index=self.index, 
                    columns=columns
                )


class DataLoader(object):

    def __call__(
        self,
        healthy_X,
        nodes
    ) -> None:

        self.healthy = Zanin(healthy_X, nodes)
        print('Data for healthy loaded successfully')

        self.features = Features(self.healthy)
        self.features.fit()
        print('Features computed successfully')
    
        self.models = Model(self.healthy, self.features)
        self.models.fit() 
        print('Models fitted successfully')

class DataFitter(object):

    def __init__(
        self,
        dataloader: DataLoader,
        newdata
    ) -> None:

        self.train_data = NewData(newdata, dataloader.healthy, dataloader.features, dataloader.models)
        self.train_data.fit()
        print('New data fitted successfully')

        self.graphs = GraphBasket(self.train_data, dataloader.features)
        self.graphs.fit()
        print('Graphs created...')

    def create_chars(self):

        self.graphs.compute()
        return self.graphs.chars